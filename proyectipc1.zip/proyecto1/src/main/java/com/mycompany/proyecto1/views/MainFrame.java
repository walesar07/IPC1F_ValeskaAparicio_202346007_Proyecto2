package com.mycompany.proyecto1.views;

import com.mycompany.proyecto1.controllers.AnimalControllers;
import com.mycompany.proyecto1.controllers.UsuarioControllers;
import com.mycompany.proyecto1.controllers.ArchivoControllers;
import com.mycompany.proyecto1.controllers.AdoptanteControllers;
import com.mycompany.proyecto1.controllers.SolicitudControllers;
import com.mycompany.proyecto1.models.Usuario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MainFrame extends JFrame {

    private Usuario usuarioLogueado;
    private AnimalControllers animalController;
    private UsuarioControllers usuarioController;
    
    // Controladores adicionales para el flujo completo
    private AdoptanteControllers adoptanteController;
    private SolicitudControllers solicitudController;

    private JButton btnGestionAnimales;
    private JButton btnGestionUsuarios;
    private JButton btnGestionAdopciones;
    private JButton btnReportes;
    private JButton btnCerrarSesion;

    public MainFrame(Usuario usuarioLogueado, AnimalControllers animalController, UsuarioControllers usuarioController) {
        this.usuarioLogueado = usuarioLogueado;
        this.animalController = animalController;
        this.usuarioController = usuarioController;
        
        // Inicialización de controladores auxiliares si no vienen pasados
        this.adoptanteController = new AdoptanteControllers(100);
        this.solicitudController = new SolicitudControllers(100);

        configurarVentana();
        inicializarComponentes();
        aplicarPermisos();
    }

    private void configurarVentana() {
        setTitle("Sistema Refugio de Animales - Menú Principal");
        setSize(450, 380);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Persistencia: Guardar datos automáticamente al cerrar con la X
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                ArchivoControllers.guardarAnimalCSV(animalController.obtenerTodosLosAnimales(), "animales.csv");
            }
        });
    }

    private void inicializarComponentes() {
        JPanel panel = new JPanel();
        panel.setLayout(null);

        // Encabezado con información del usuario y rol
        JLabel lblBienvenida = new JLabel("Bienvenido: " + usuarioLogueado.getUsuario(), SwingConstants.CENTER);
        lblBienvenida.setBounds(50, 15, 350, 20);
        panel.add(lblBienvenida);

        JLabel lblRol = new JLabel("Rol: " + usuarioLogueado.getRol(), SwingConstants.CENTER);
        lblRol.setBounds(50, 35, 350, 20);
        panel.add(lblRol);

        // Botón 1: Gestión de Animales
        btnGestionAnimales = new JButton("Gestión de Animales");
        btnGestionAnimales.setBounds(100, 75, 250, 35);
        panel.add(btnGestionAnimales);

        // Botón 2: Gestión de Usuarios Auxiliares (Exclusivo Administrador)
        btnGestionUsuarios = new JButton("Gestión de Auxiliares");
        btnGestionUsuarios.setBounds(100, 125, 250, 35);
        panel.add(btnGestionUsuarios);

        // Botón 3: Adopciones
        btnGestionAdopciones = new JButton("Registro de Adopciones");
        btnGestionAdopciones.setBounds(100, 175, 250, 35);
        panel.add(btnGestionAdopciones);

        // Botón 4: Reportes / Carga de Archivos
        btnReportes = new JButton("Reportes del Sistema");
        btnReportes.setBounds(100, 225, 250, 35);
        panel.add(btnReportes);

        // Botón 5: Cerrar Sesión
        btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.setBounds(150, 280, 150, 30);
        panel.add(btnCerrarSesion);

        // --- Acciones de los botones ---

        // Abrir la pantalla de Gestión de Animales (AnimalForm)
        btnGestionAnimales.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AnimalForm animalForm = new AnimalForm(animalController);
                animalForm.setVisible(true);
            }
        });

        // Evento para Gestión de Usuarios
        btnGestionUsuarios.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                UsuarioForm usuarioForm = new UsuarioForm(usuarioController);
                usuarioForm.setVisible(true);
            }
        });

        // Evento para Adopciones: Conectado a SolicitudView
        btnGestionAdopciones.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SolicitudView solicitudView = new SolicitudView(solicitudController, animalController, adoptanteController);
                solicitudView.setVisible(true);
            }
        });

        // Evento para Reportes: Generación de HTML
        btnReportes.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ArchivoControllers.generarReporteHTMLAnimales(animalController.obtenerTodosLosAnimales(), "reporte_animales.html");
                JOptionPane.showMessageDialog(MainFrame.this, 
                    "¡Reporte HTML generado exitosamente como 'reporte_animales.html'!", 
                    "Reporte Generado", 
                    JOptionPane.INFORMATION_MESSAGE);
            }
        });

        // Cerrar Sesión y volver al LoginView
        btnCerrarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginView(usuarioController, animalController).setVisible(true);
            }
        });

        add(panel);
    }

    // Aplica las restricciones de interfaz de acuerdo al rol del usuario logueado.
    private void aplicarPermisos() {
        if (usuarioLogueado.getRol() != null && usuarioLogueado.getRol().equalsIgnoreCase("USUARIO AUXILIAR")) {
            // Un usuario auxiliar no puede registrar ni gestionar otros usuarios
            btnGestionUsuarios.setEnabled(false);
            btnGestionUsuarios.setToolTipText("Opción reservada exclusivamente para Administradores.");
        }
    }
}