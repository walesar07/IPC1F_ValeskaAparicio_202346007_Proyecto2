package com.mycompany.proyecto1.views;

import com.mycompany.proyecto1.controllers.AdoptanteControllers;
import com.mycompany.proyecto1.models.Adoptante;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdoptanteView extends JFrame {

    private JTextField txtDpi;
    private JTextField txtNombre;
    private JTextField txtTelefono;
    private JTextField txtCorreo;
    private JTextField txtDireccion;

    private JButton btnGuardar;
    private JButton btnEliminar;
    private JButton btnLimpiar;
    private JTable tblAdoptantes;
    private DefaultTableModel modeloTabla;

    private AdoptanteControllers adoptanteController;

    public AdoptanteView(AdoptanteControllers adoptanteController) {
        this.adoptanteController = adoptanteController;

        configurarVentana();
        inicializarComponentes();
        cargarDatosTabla();
    }

    private void configurarVentana() {
        setTitle("Gestión de Adoptantes");
        setSize(680, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private void inicializarComponentes() {
        JPanel panel = new JPanel();
        panel.setLayout(null);

        JLabel lblTitulo = new JLabel("REGISTRO DE ADOPTANTES", SwingConstants.CENTER);
        lblTitulo.setBounds(20, 15, 620, 25);
        panel.add(lblTitulo);

        // DPI
        JLabel lblDpi = new JLabel("DPI / ID:");
        lblDpi.setBounds(30, 55, 100, 25);
        panel.add(lblDpi);

        txtDpi = new JTextField();
        txtDpi.setBounds(120, 55, 170, 25);
        panel.add(txtDpi);

        // Nombre
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 90, 100, 25);
        panel.add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(120, 90, 170, 25);
        panel.add(txtNombre);

        // Teléfono
        JLabel lblTelefono = new JLabel("Teléfono:");
        lblTelefono.setBounds(30, 125, 100, 25);
        panel.add(lblTelefono);

        txtTelefono = new JTextField();
        txtTelefono.setBounds(120, 125, 170, 25);
        panel.add(txtTelefono);

        // Correo
        JLabel lblCorreo = new JLabel("Correo:");
        lblCorreo.setBounds(320, 55, 100, 25);
        panel.add(lblCorreo);

        txtCorreo = new JTextField();
        txtCorreo.setBounds(410, 55, 200, 25);
        panel.add(txtCorreo);

        // Dirección
        JLabel lblDireccion = new JLabel("Dirección:");
        lblDireccion.setBounds(320, 90, 100, 25);
        panel.add(lblDireccion);

        txtDireccion = new JTextField();
        txtDireccion.setBounds(410, 90, 200, 25);
        panel.add(txtDireccion);

        // Botones
        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(140, 165, 110, 30);
        panel.add(btnGuardar);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(275, 165, 110, 30);
        panel.add(btnEliminar);

        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setBounds(410, 165, 110, 30);
        panel.add(btnLimpiar);

        // Tabla
        modeloTabla = new DefaultTableModel(new Object[]{"DPI", "Nombre", "Teléfono", "Correo", "Dirección"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblAdoptantes = new JTable(modeloTabla);
        JScrollPane scroll = new JScrollPane(tblAdoptantes);
        scroll.setBounds(30, 215, 610, 220);
        panel.add(scroll);

        // Eventos
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarAdoptante();
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarAdoptante();
            }
        });

        btnLimpiar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });

        add(panel);
    }

    private void guardarAdoptante() {
        String dpi = txtDpi.getText().trim();
        String nombre = txtNombre.getText().trim();
        String telefono = txtTelefono.getText().trim();
        String correo = txtCorreo.getText().trim();
        String direccion = txtDireccion.getText().trim();

        if (dpi.isEmpty() || nombre.isEmpty() || telefono.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El DPI, Nombre y Teléfono son obligatorios.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Se usa el constructor de Adoptante correspondiente
        Adoptante nuevo = new Adoptante(dpi, nombre, telefono, correo, direccion,true);
        boolean exito = adoptanteController.agregarAdoptante(nuevo);

        if (exito) {
            JOptionPane.showMessageDialog(this, "Adoptante registrado correctamente.");
            limpiarCampos();
            cargarDatosTabla();
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo registrar. Verifique si el DPI ya existe o la capacidad está llena.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarAdoptante() {
        int fila = tblAdoptantes.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un adoptante de la tabla para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String dpi = (String) modeloTabla.getValueAt(fila, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "¿Desea dar de baja al adoptante con DPI " + dpi + "?", "Confirmar", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (adoptanteController.eliminarAdoptante(dpi)) {
                JOptionPane.showMessageDialog(this, "Adoptante eliminado con éxito.");
                cargarDatosTabla();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo eliminar el registro.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void cargarDatosTabla() {
        modeloTabla.setRowCount(0);
        if (adoptanteController == null) return;

        // Se llama a obtenerAdoptantes() de tu controlador
        Adoptante[] activos = adoptanteController.obtenerAdoptantes();
        if (activos != null) {
            for (Adoptante a : activos) {
                if (a != null) {
                    modeloTabla.addRow(new Object[]{
                        a.getDpi(),
                        a.getNombreCompleto(),
                        a.getTelefono(),
                        a.getCorreo(),
                        a.getDireccion()
                    });
                }
            }
        }
    }

    private void limpiarCampos() {
        txtDpi.setText("");
        txtNombre.setText("");
        txtTelefono.setText("");
        txtCorreo.setText("");
        txtDireccion.setText("");
    }
}